package com.example.bmi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.BreakIterator;

public class MainActivity extends AppCompatActivity {

    EditText wzrost, waga;
    TextView wynik;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        wzrost = (EditText) findViewById(R.id.wzrost);
        waga = (EditText) findViewById(R.id.waga);
        wynik = (TextView) findViewById(R.id.wynik);
        button = (Button) findViewById(R.id.button);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                obliczBMI();
            }
        });
    }

    private void obliczBMI(){
        String wzrostStr = wzrost.getText().toString();
        String wagatStr = waga.getText().toString();

        if (wzrostStr != null && !"".equals(wzrostStr) && wagatStr != null && !"".equals(wagatStr)){
            float wzrostValue = Float.parseFloat(wzrostStr) / 100;
            float wagaValue = Float.parseFloat(wagatStr);

            float bmi = wagaValue / (wzrostValue * wzrostValue);

            displayBMI(bmi);
        }
    }

    private void displayBMI(float bmi){
        String bmiLabel = "";
        if (Float.compare(bmi, 16f) <= 0){
            bmiLabel = "Wygłodzenie";
        }else if (Float.compare(bmi, 16f) > 0 && Float.compare(bmi, 16.99f) <= 0){
            bmiLabel = "Wychudzenie";
        }else if (Float.compare(bmi, 17f) > 0 && Float.compare(bmi, 18.49f) <= 0){
            bmiLabel = "niedowaga";
        }else if (Float.compare(bmi, 18.50f) > 0 && Float.compare(bmi, 24.99f) <= 0){
            bmiLabel = "wartość prawidłowa";
        }else if (Float.compare(bmi, 25f) > 0 && Float.compare(bmi, 29.99f) <= 0){
            bmiLabel = "nadwaga";
        }else if (Float.compare(bmi, 30f) > 0 && Float.compare(bmi, 34.99f) <= 0){
            bmiLabel = "1 stopień otyłości";
        }else if (Float.compare(bmi, 35f) > 0 && Float.compare(bmi, 39.99f) <= 0){
            bmiLabel = "2 stopień otyłości";
        }else if (Float.compare(bmi, 40f) > 0 && Float.compare(bmi, 99f) <= 0){
        bmiLabel = "otyłość skrajna";
        }

        bmiLabel = bmi + "/n" + bmiLabel;

    }


}